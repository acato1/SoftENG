-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 18, 2016 at 07:09 PM
-- Server version: 5.1.57
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `a9270051_testcal`
--

-- --------------------------------------------------------

--
-- Table structure for table `testcal`
--

CREATE TABLE `testcal` (
  `name` varchar(16) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(16) COLLATE latin1_general_ci NOT NULL,
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `lock_code` varchar(0) COLLATE latin1_general_ci NOT NULL,
  `unlock_code` varchar(0) COLLATE latin1_general_ci NOT NULL,
  `color` varchar(0) COLLATE latin1_general_ci NOT NULL,
  `time` varchar(0) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(16) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `testcal`
--

